# @image-lab/client

Product-independent Node 22.12+ client. No runtime dependencies, Electron or React imports.

Build with `npm ci && npm run build`. The private package has not been published; consume it via a workspace/file dependency or `npm pack` output. See the project root README for usage.

`removeBackground(Blob, { signal, timeoutMs, onStatus })` waits for completion, downloads foreground and mask Blobs, then releases the server result. The default overall timeout is 420 seconds. No automatic POST retries. Cleanup uses a fresh signal with a 2-second deadline; TTL is the fallback after a disconnect or service failure.

For explicit lifecycle control use `submitBackgroundRemoval`, `getJob`, `download`, and `cancelJob`. Artifact downloads reject other origins and redirects to avoid forwarding credentials to an unrelated server.

The HTTP API is intended for trusted main processes and product backends. Browser apps should call their own backend, not embed the service token in client code.
