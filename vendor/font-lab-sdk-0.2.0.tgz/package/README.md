# @font-lab/sdk

Font Lab 的轻量 TypeScript HTTP SDK，支持浏览器与 Node，无 React 或模型依赖。

```ts
import { createFontClient } from '@font-lab/sdk'
const client = createFontClient({baseUrl:'/api/v1'})
const result = await client.scan(file, {topK:5})
const creation = await client.creations.create({mode:'prompt', prompt:'圆润的中文手写字', chars:'春风花草'})
const job = await client.generations.create({creation_id:creation.id})
const step = await client.generations.wait(job.id)
// 如果 step.status === 'awaiting_review'，先展示参考字，请用户确认。
```

服务端可设置 apiKey，浏览器通过接入项目的后端转发，不要把项目密钥放到前端。所有方法支持取消信号；wait 的超时或取消只停止等待，不取消服务器任务。创建时可提供 idempotencyKey 去重，SDK 不自动重试写操作。

成功生成状态是 exported。使用 fontFile(step.font_id) 获取 Response，再读取 arrayBuffer/blob/body。`library.file()` 返回收藏时固定的文件。`generations.file(id, 'export/font-lab.zip')` 获取包含 TTF、SVG、PNG 的完整包。

浏览器辅助函数位于 `@font-lab/sdk/browser`。具体接口见仓库 docs/service.md 和 OpenAPI。`make sdk-pack` 生成可供独立项目安装的 tgz。

示例与资源访问方式见仓库 docs/service.md；示例接口统一为 /api/v1/examples。
