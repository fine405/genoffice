# @lens/sdk

Browser / Node 22+ font-service client, with no runtime dependencies. The client calls a deployed Python service; it does not install or run OCR/model weights. Public response types are generated from the service OpenAPI contract.

```ts
import { createFontClient, FontServiceError } from '@lens/sdk'

const client = createFontClient({ baseUrl: '/api/v1' })
const image = await client.upload(file) // File or Blob; alternatively { imageUrl }
const result = await client.scan({ imageId: image.image_id }, {
  topK: 5, ocrEngine: 'paddleocr', signal: controller.signal,
})
// Or client.scan(file, options) to upload and scan in one SDK call.
const font = await client.font(chosenFontId)
const bytes = await (await client.fontFile(font.font_id)).arrayBuffer()
```

`baseUrl` includes `/api/v1`; browser apps normally call a same-origin backend proxy. Configure `apiKey` only on a trusted server. No project credentials belong in a frontend bundle. `fetch`, `headers`, and per-request `timeoutMs` are configurable. Caller cancellation and timeout both apply; abort errors retain their native names. HTTP failures throw `FontServiceError` with `status`, `code`, `requestId`, and optional `retryAfterSeconds`. No automatic retries; aborting a request does not cancel an already-running inference.

Methods: `upload`, `scan`, `capabilities`, `imageFile`, `deleteImage`, `font`, `fontFile`. The last returns a Response for Blob/ArrayBuffer/stream consumption. All accept an optional AbortSignal. `scan` accepts a Blob, `{imageUrl}`, or `{imageId}`; `cropBox` coordinates are normalized-original pixels. Uploaded resources expire; a failed scan after a convenience upload may leave an image for TTL cleanup. Use explicit upload when you need its ID for retry/deletion.

Optional browser entrypoint:

```ts
import { loadPreviewFont, downloadFont } from '@lens/sdk/browser'
const preview = await loadPreviewFont(client, font)
element.style.fontFamily = `"${preview.family}"`
element.style.fontWeight = String(font.weight)
element.style.fontStyle = font.style
// When no element uses this preview anymore:
preview.dispose()
await downloadFont(client, font)
```

Persist `FontSelection` using real font IDs/names, never the temporary preview alias. File details include actual format, SHA-256, internal font names, and raw embedding flags. License status is currently unknown; these fields do not promise commercial rights, document embedding, or editor compatibility. No font conversion or system installation is performed.

## Build and install in another project

From repository root:

```bash
pnpm install --frozen-lockfile
pnpm --filter @lens/sdk build
mkdir -p artifacts
pnpm --dir packages/sdk pack --pack-destination ../../artifacts
# In the consuming project, use the actual generated archive path:
pnpm add /absolute/path/to/lens-web/artifacts/lens-sdk-0.1.0.tgz
```

The package is currently private/unpublished; no npm registry access is required to use the archive. Node example:

```ts
import { readFile, writeFile } from 'node:fs/promises'
import { createFontClient } from '@lens/sdk'
const client = createFontClient({
  baseUrl: process.env.FONT_SERVICE_URL + '/api/v1',
  apiKey: process.env.FONT_SERVICE_API_KEY,
})
const result = await client.scan(new Blob([await readFile('reference.png')]))
// chosenFontId should come from the user's explicit variant selection.
const font = await client.font(chosenFontId)
await writeFile(`selected.${font.format}`, new Uint8Array(
  await (await client.fontFile(font.font_id)).arrayBuffer(),
))
```

See [service contract](../../docs/service.md) and the [independent editor example](../../examples/editor/README.md).
